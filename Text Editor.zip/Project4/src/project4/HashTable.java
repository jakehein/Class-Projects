package project4;

public class HashTable {
	private HashNode[] hashTable;
	private float loadFactor;
	private int numElements;
	
	public HashTable() {
		hashTable = new HashNode[11];
		numElements = 0;
		loadFactor = (float) numElements / hashTable.length;
	}
	
	public void rehash(int primeLength) {
		HashNode[] bigTable = new HashNode[primeLength];
		int iElements = numElements;
		int count = 0;
		while (iElements > 0) {
			if (hashTable[count] != null) {
				////
				
				HashNode word = hashTable[count];
				int slot = word.getKey() % bigTable.length;
				int i = 0;
				int j = slot + (int) Math.pow(i,2);
				
				while (bigTable[j] != null) {
					i++;
					j = (slot + (int) Math.pow(i,2)) % bigTable.length;
				}
				bigTable[j] = word;
				////
				iElements--;
			}
			count++;
		}
		hashTable = bigTable;
		updateLoadFactor();
	}
	
	public void updateLoadFactor() {
		loadFactor = (float) numElements / hashTable.length;
		if(loadFactor >= .5)
			nextPrime(hashTable.length);
	}
	
	public void nextPrime(int inNumber) {
			int prime = (inNumber << 1) + 1;
			for (int i = 3; i < prime; i++)
				if (prime % i == 0) {
					prime = prime + 2;
					i = 3;
				}
		rehash(prime);
	}
	
	public void insert(String inValue) {
		HashNode word = new HashNode(inValue);
		int slot = word.getKey() % hashTable.length;
		int i = 0;
		int j = slot + (int) Math.pow(i,2);   //int iSquared = (int) Math.pow(i, 2);
		
		while (hashTable[j] != null) {
			i++;
			j = (slot + (int) Math.pow(i, 2)) % hashTable.length;
		}
		hashTable[j] = word;
		numElements++;
		updateLoadFactor();
	}
	//////////////////////
	/*public static void main(String[] args) {
		HashTable hashTable = new HashTable();
		hashTable.insert("red");
		hashTable.insert("red");
		hashTable.insert("red");
		hashTable.insert("red");
		hashTable.insert("red");
		hashTable.insert("red");
		hashTable.insert("cyan");
		hashTable.insert("purple");
		hashTable.insert("brown");
		hashTable.insert("1");
		hashTable.insert("2");
		hashTable.insert("3");
		
		hashTable.printHash();
		
				
	}*/
	/////////////////////
	@Override
	public String toString() {
		String string = "";
		for(HashNode current : hashTable) {
			if (current != null)
				string = string + current.getValue() + "\n";
		}
		return string;
	}
	public void printHash() {
		
		System.out.print("Table: [");
		for(HashNode current : hashTable) {
			if (current != null)
				System.out.print("(" + current.getKey() + "," + current.getValue() + "), ");
		}
		System.out.print("]");
		
	}
	
	public HashNode search(int inKey) {
		int slot = inKey % hashTable.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		//int iSquared = (int) Math.pow(i, 2);
		
		while (hashTable[j] != null) {
			if (hashTable[j].getKey() == inKey)
				return hashTable[j];
			i++;
			j = (slot + (int) Math.pow(i, 2)) % hashTable.length;
		}
		//HashNode element = new HashNode();
		return null; //element;
	}
}
