package project4;

public class HashNode {
	public int key;
	public String value;
	
	
	public HashNode(String inValue) {
		key = Math.abs(inValue.hashCode());
		value = inValue;
	}
	
	//public void setKey(String inValue) {
	//	key = Math.abs(inValue.hashCode());
	//}
	
	//public void setValue(String inValue) {
	//	value = inValue;
	//}
	
	public int getKey() {
		return key;
	}
	
	public String getValue() {
		return value;
	}
}
