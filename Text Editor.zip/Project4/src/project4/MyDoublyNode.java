package project4;

/**
 * @description This class creates the framework of a MyDoublyNode, which will be used for the 
 * 				QueueList class. MyDoublyNode objects contain char elements and pointers
 * 				to their neighboring MyDoublyNodes.
 * @author Jacob Hein
 * @version 3/1/2019
 */
public class MyDoublyNode {

	private String element;
    private MyDoublyNode next, previous;
    
    /**
     * Constructor
     */
    public MyDoublyNode(){
        element = null;
        next = null;
        previous = null;
    }
    
    /**
     * Constructor
     * @param data element being passed into the constructor.
     */
    public MyDoublyNode(String data){
        element = data;
    }
    
    /**
     * Constructor
     * @param data element being passed into the constructor.
     * @param next forward neighbor being pointed to.
     * @param previous previous neighbor being pointed to.
     */
    public MyDoublyNode(String data, MyDoublyNode next, MyDoublyNode previous){
        element = data;
        this.next = next;
        this.previous = previous;
    }
    
    /**
     * This method sets the previous MyDoublyNode of the current Node.
     * @param previous is the node being pointed to.
     */
    public void setPrevious(MyDoublyNode previous){
        this.previous = previous;
    }
    
    /**
     * This method gets the previous MyDoublyNode and returns it to the user.
     * @return previous is the node being pointed to.
     */
    public MyDoublyNode getPrevious(){
        return previous;
    }
    
    /**
     * This method sets the next MyDoublyNode object being pointed to.
     * @param next is the next object being pointed to.
     */
    public void setNext(MyDoublyNode next){
        this.next = next;
    }
    
    /**
     * This method gets the next MyDoublyNode object being pointed to and returns it to the user.
     * @return next is the neighboring object being pointed to.
     */
    public MyDoublyNode getNext(){
        return next;
    }
    
    /**
     * This method sets the value held by the current MyDoublyNode object to the char param.
     * @param data is the char value being set to the object.
     */
    public void setData(String data){
        element = data;
    }
    
    /**
     * This method gets the value held by the current MyDoublyNode object and returns it to the user.
     * @return element is the char being stored in the current MyDoublyNode object.
     */
    public String getData(){
        return element;
    }
}
