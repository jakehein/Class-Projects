package project4;



/**
 * @description This class creates a StackList based on the framework of a LinkedList and
 * 				a MyNode class. It enables the user to push/pop char elements from the StackList
 * 				and determine the StackList's size and emptiness. Runtimes are given for each
 * 				method.
 * @author Jacob Hein
 * @version 3/1/2019
 *
 */
public class StackList {

	private MyNode head;
   
	/**
	 * Constructor
	 */
    public StackList(){
        head = null;
    }
    
    /**
     * This method pushes char elements onto the StackList.
     * The runtime of this method is \theta(n) as it runs the length of the number of elements
     * currently in the StackList in order to push a new element.
     * @param x is the char element being pushed onto the StackList.
     */
    public void push(String x) {
    	MyNode insertMe = new MyNode(x, null);
    	if(head == null || head.getData() == null) // added head.getData
    		head = insertMe;
    	else {
            MyNode current = head;
            while(current.getNext()!=null && current.getNext().getData() != null)
            		current = current.getNext();
            current.setNext(insertMe);
    	}
    }
    
    /**
     * This method pops the most recent element from the StackList, returning it to the user.
     * The runtime of this method is \theta(n) as it runs through all the elements being stored
     * and pops them from the list. 
     * @return returnPop is the char element being returned from the StackList.
     */
    public String pop() {
    	String returnPop = null;
    	
    	if(head == null || head.getData() == null) {
    		//System.out.println("Stack empty");
    		//return null;
    		//throw new RuntimeException("Trying to pop from an empty StackList.");
    	} else{
            MyNode current = head;
            while(current.getNext() != null && current.getNext().getData() != null)
                current = current.getNext();
            returnPop = current.getData();
            current.setData(null);
    	}
        return returnPop;
    }
    
    public String peek() {
    	String returnPeek = null;
    	if (head != null || head.getData() != null) {
    		MyNode current = head;
    		while (current.getNext() != null && current.getNext().getData() != null)
    			current = current.getNext();
    		returnPeek = current.getData();
    	}
    	return returnPeek;
    }
    
    /**
     * This method returns true or false depending on the emptiness of the StackList.
     * The runtime of this method is \theta(1) as it checks the head of the list and then ends.
     * @return returnEmpty is the returned value based on the assignment of MyNode head.
     */
    public boolean isEmpty() {
    	boolean returnEmpty = false;
    	if(head == null || head.getData() == null)
    		//clear();
    		returnEmpty = true;
    	return returnEmpty;
    }
    
    /**
     * This method returns the number of elements being stored in the StackList. 
     * The runtime of this method is \theta(n) as it counts through all the elements
     * being stored and returns the number of elements.
     * @return returnSize is the number of elements being stored in the StackList.
     */
    public int size() {
    	int returnSize = 0;
    	MyNode current = head;
    	if (current != null)
    		returnSize = 1;
    	while(current.getNext().getData() != null) {
    		current = current.getNext();
    		returnSize++;
    	}
    	return returnSize;
    }
    
    public void printStack() {
    	MyNode current = head;
    	while (current != null) {
    		System.out.println(current.getData());
    		current = current.getNext();
    	}
    }
    /*
     * ideally, this should just clear the entire stack. Useful for clearing out redo
     * after I've hit undo multiple times then start typing.
     */
    public void clear() {
    	head = null;
    }
}
