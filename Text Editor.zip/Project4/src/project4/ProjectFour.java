package project4;

import java.awt.*;
import javax.swing.*;
import java.io.*;
import java.util.Scanner;
import java.awt.event.*;
import javax.swing.JScrollPane;

public class ProjectFour extends JFrame implements KeyListener, ActionListener {

	private JTextArea textArea;
	private JFrame frame;

	private String word;
	private StackList undo = new StackList();
	private StackList redo = new StackList();
	private StackList spelling = new StackList();
	private static HashTable dictionary = new HashTable();
	final char[] alphabet = { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 
			'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r',
			's', 't', 'u', 'v', 'w', 'x', 'y', 'z' };

	/**
	 * Default constructor to setup the screen. No need to edit this method.
	 * 
	 **/
	public ProjectFour() {
		frame = new JFrame("CS271 Awesome Editor");
		textArea = new JTextArea();
		JScrollPane scrollPane = new JScrollPane(textArea, JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
				JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		JMenuBar menuBar = new JMenuBar();
		JMenu menuItems = new JMenu("File");

		JMenuItem newItem = new JMenuItem("New");
		JMenuItem openItem = new JMenuItem("Open");
		JMenuItem saveItem = new JMenuItem("Save");
		JMenuItem quitItem = new JMenuItem("Quit");

		newItem.addActionListener(this);
		openItem.addActionListener(this);
		saveItem.addActionListener(this);
		quitItem.addActionListener(this);

		menuItems.add(newItem);
		menuItems.add(openItem);
		menuItems.add(saveItem);
		menuItems.add(quitItem);

		JMenu doStuffMenu = new JMenu("Actions");

		JMenuItem undoItem = new JMenuItem("Undo");
		JMenuItem redoItem = new JMenuItem("Redo");
		JMenuItem solveMathItem = new JMenuItem("Solve Math");
		JMenuItem spellCheckItem = new JMenuItem("Spell Check");
		JMenuItem printUndo = new JMenuItem("Print Undo Stack");
		JMenuItem printRedo = new JMenuItem("Print Redo Stack");

		undoItem.addActionListener(this);
		redoItem.addActionListener(this);
		solveMathItem.addActionListener(this);
		spellCheckItem.addActionListener(this);
		printUndo.addActionListener(this);
		printRedo.addActionListener(this);

		doStuffMenu.add(undoItem);
		doStuffMenu.add(redoItem);
		doStuffMenu.add(solveMathItem);
		doStuffMenu.add(spellCheckItem);
		doStuffMenu.add(printUndo);
		doStuffMenu.add(printRedo);

		menuBar.add(menuItems);
		menuBar.add(doStuffMenu);

		undoItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Z, InputEvent.CTRL_MASK));
		redoItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Y, InputEvent.CTRL_MASK));

		frame.setJMenuBar(menuBar);
		// kill the program instead of just hiding the frame
		frame.addWindowListener(new java.awt.event.WindowAdapter() {
			public void windowClosing(java.awt.event.WindowEvent windowEvent) {
				System.exit(0);
			}
		});

		textArea.addKeyListener(this);
		frame.add(scrollPane);
		frame.setSize(600, 600);
		frame.show();
	}

	/**
	 * This method will prompt the user to choose a folder to save a file. No need
	 * to edit this method.
	 **/
	private void saveFile() {
		JFileChooser fileChooser = new JFileChooser("Save");
		int answer = fileChooser.showSaveDialog(null);
		if (answer == JFileChooser.APPROVE_OPTION) {
			File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
			try {
				BufferedWriter output = new BufferedWriter(new FileWriter(file));
				output.write(textArea.getText());
				output.flush();
				output.close();
			} catch (Exception e) {
				JOptionPane.showMessageDialog(frame, e.getMessage());
			}
			JOptionPane.showMessageDialog(frame, "File Saved.");
		} else {
			JOptionPane.showMessageDialog(frame, "Canceled Save Request.");
		}
	}

	/**
	 * This method will prompt the user to choose a file to open. No need to edit
	 * this method.
	 **/
	private void openFile() {
		JFileChooser fileChooser = new JFileChooser("Open");
		int answer = fileChooser.showOpenDialog(null);
		if (answer == JFileChooser.APPROVE_OPTION) {
			File file = new File(fileChooser.getSelectedFile().getAbsolutePath());
			try {
				String line;
				String outputText;
				BufferedReader fin = new BufferedReader(new FileReader(file));
				outputText = fin.readLine();
				while ((line = fin.readLine()) != null) {
					outputText += "\n" + line;
				}
				textArea.setText(outputText);
			} catch (Exception evt) {
				JOptionPane.showMessageDialog(frame, evt.getMessage());
				return;
			}
			JOptionPane.showMessageDialog(frame, "Successfully opened file.");
		} else {
			JOptionPane.showMessageDialog(frame, "Cancelled file opening.");
		}
	}

	/**
	 * Not used in this project but needed because of the interface.
	 **/
	public void keyPressed(KeyEvent e) {
		if ((e.getModifiers() & KeyEvent.CTRL_MASK) == 2)
			return;
		if (e.isControlDown() && e.getKeyCode() == KeyEvent.VK_Z)
			return;
		redo.clear();
	}

	/**
	 * Not used in this project but needed because of the interface.
	 **/
	public void keyReleased(KeyEvent e) {
		if (e.isControlDown()) {
		} else {
			try {
				String textCheck = textArea.getText();
				if (textCheck.contentEquals(undo.peek()))
					return;
			} catch (NullPointerException ex) {
			}
			undo.push(textArea.getText());
		}
	}

	/**
	 * Method to handle keystrokes.
	 **/
	public void keyTyped(KeyEvent e) {
	}

	/**
	 * If a menu option is chosen, do something... New, Save, Open and Quit are all
	 * functional and should not be changed. Read the above code and figure out how
	 * to add methods to accomplish the tasks in the "Actions" menu bar. In other
	 * words, complete the code such that undo, redo, solve math and spell check all
	 * work.
	 **/
	public void actionPerformed(ActionEvent e) {
		String action = e.getActionCommand();
		if (action.equals("New")) {
			textArea.setText(""); // creating a new document, simple, clear text.
			undo.clear();
			redo.clear();
		} else if (action.equals("Save")) {
			saveFile(); // saving a file, done in another method
		} else if (action.equals("Open")) {
			openFile(); // opening a file, similar to saving one
		} else if (action.equals("Quit")) {
			System.exit(0);
		} else if (action.equals("Undo")) {
			undoButton();
		} else if (action.equals("Redo")) {
			redoButton();
		} else if (action.equals("Solve Math")) {
			solveButton();
		} else if (action.equals("Spell Check")) {
			Scanner scan = new Scanner(textArea.getText());
			spellCheck(scan);
		} else if (action.equals("Print Undo Stack")) {
			printUndoStack();
		} else if (action.equals("Print Redo Stack")) {
			printRedoStack();
		}
	}

	private void undoButton() {
		try {
			redo.push(undo.pop());
			String undone = undo.peek();
			textArea.setText(undone);
		} catch (NullPointerException e) {
			System.out.print("Error: " + e);
		}
	}

	private void redoButton() {
		try {
			if (redo.peek() == null)
				return;
		} catch (Exception e) {
			return;
		}
		try {
			String redone = redo.pop();
			undo.push(redone);
			textArea.setText(redone);
		} catch (NullPointerException e) {
		}
	}

	private void solveButton() {
		String solve = undo.peek();
		int index = 0;
		String equation = "";
		String variables = "";
		String trueEquation = "";
		String value = "";
		String var, val;
		while (solve.contains("***")) {
			index = solve.indexOf("***");
			equation = solve.substring(index + 3);
			equation = equation.substring(0, equation.indexOf("***"));
			solve = solve.replace("***" + equation + "***", "|||");
			if (equation.contains(":")) {
				variables = equation.substring(0, equation.indexOf(':'));
				trueEquation = equation.substring(equation.indexOf(':') + 1);
				while (variables.contains("=")) {
					int eqIndex = variables.indexOf('=');
					var = variables.substring(0, eqIndex);
					if (variables.contains(",")) {
						val = variables.substring(eqIndex + 1, variables.indexOf(","));
						variables = variables.substring(variables.indexOf(",") + 1);
					} else {
						val = variables.substring(eqIndex + 1);
						variables = variables.substring(eqIndex + 1);
					}
					trueEquation = trueEquation.replaceAll(var, val);
				}
				value = equationSolver(trueEquation);
			} else {
				value = equationSolver(equation);
			}
			solve = solve.replace("|||", value);
		}
		textArea.setText(solve);
		undo.push(solve);
	}

	private void appendToWord(String inWord) {
		String outWord = inWord;
		for (int i = 0; i < outWord.length() + 1; i++) {
			for (char letter : alphabet) {
				String subStart = outWord.substring(0, i);
				String subEnd = outWord.substring(i);
				String newWord = subStart + letter + subEnd;
				if (dictionary.search(Math.abs(newWord.hashCode())) != null
						&& dictionary.search(Math.abs(newWord.hashCode())).getKey() == Math.abs(newWord.hashCode())) {
					spelling.push(newWord);
				}
			}
		}
	}

	private void removeLetter(String inWord) {
		String outWord = inWord;
		for (int i = 0; i < outWord.length(); i++) {
			String subStart = outWord.substring(0, i);
			String subEnd = outWord.substring(i + 1);
			String newWord = subStart + subEnd;
			if (dictionary.search(Math.abs(newWord.hashCode())) != null
					&& dictionary.search(Math.abs(newWord.hashCode())).getKey() == Math.abs(newWord.hashCode())) {
				spelling.push(newWord);
			}
		}
	}

	private void swapConsec(String inWord) {
		String outWord = inWord;
		for (int i = 0; i < outWord.length() - 1; i++) {
			char letter1 = outWord.charAt(i);
			char letter2 = outWord.charAt(i + 1);
			String subStart = outWord.substring(0, i);
			try {
				String subEnd = outWord.substring(i + 2, outWord.length());
				String newWord = subStart + letter2 + letter1 + subEnd;
				if (dictionary.search(Math.abs(newWord.hashCode())) != null
						&& dictionary.search(Math.abs(newWord.hashCode())).getKey() == Math.abs(newWord.hashCode())) {
					spelling.push(newWord);
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				String subEnd = "";
				String newWord = subStart + letter2 + letter1 + subEnd;
				if (dictionary.search(Math.abs(newWord.hashCode())) != null
						&& dictionary.search(Math.abs(newWord.hashCode())).getKey() == Math.abs(newWord.hashCode())) {
					spelling.push(newWord);
				}
			}
		}
	}

	private void populate(String inWord) {
		word = inWord;
		char last = word.charAt(word.length() - 1);
		if (word.length() == 1) {
			appendToWord(word);
		} else if (word.charAt(0) != '*' && word.charAt(1) != '*') {
			if (last == '!' || last == '?' || last == ',' || last == '.' || 
				last == '\'' || last == '"' || last == ':'|| last == ';')
				word = word.substring(0, word.length() - 1);
			int wordKey = Math.abs(word.hashCode());
			if (dictionary.search(wordKey) == null || dictionary.search(wordKey).getKey() != wordKey) {
				appendToWord(word);
				removeLetter(word);
				swapConsec(word);
			}
		}
	}

	private JButton[] populateButtons(JFrame spellChecking) {
		JButton[] buttonArray = new JButton[10];
		int i = 0;
		while (!spelling.isEmpty() && i < 10) {
			String wordText = spelling.pop();
			JButton button = new JButton();
			button.setSize(button.getPreferredSize());
			button.setText(wordText);
			spellChecking.add(button);
			buttonArray[i] = button;
			i++;
		}
		return buttonArray;
	}

	private void spellCheck(Scanner scan) {
		JFrame spellChecking = new JFrame("Spell Check");
		spellChecking.setVisible(true);
		if (textArea.getText().contentEquals("")) {
			JOptionPane.showMessageDialog(frame, "What's the big idea!?!?\nThere's no text to correct!");
			spellChecking.dispose();
			return;
		} else if (!scan.hasNext()) {
			JOptionPane.showMessageDialog(frame, "No errors detected.");
			spellChecking.dispose();
			
		} else if (scan.hasNext()) {
			spelling.clear();
			word = scan.next();
			populate(word);
			
			spellChecking.setLayout(new GridLayout(10, 10));
			spellChecking.setSize(400, 400);
			JButton[] buttons = populateButtons(spellChecking);
			if(buttons[0] == null) {
				spellCheck(scan);
				spellChecking.dispose();
			}
			for (JButton button : buttons) {
					if (button != null)
						button.addMouseListener(new java.awt.event.MouseAdapter() {
							@Override
							public void mouseReleased(MouseEvent e) {
								String checkedWord = button.getText();
								String changeText = textArea.getText();
								changeText = changeText.replace(word, checkedWord);
								textArea.setText(changeText);
								undo.push(changeText);
								spellChecking.dispose();
								if (scan.hasNext())
									spellCheck(scan);
							}
						});
			}
		}
	}

	private String equationSolver(String inEquation) {
		StackList stack = new StackList();
		QueueList postfix = new QueueList();
		boolean repeat;
		int i;
		int partSum;
		String token, U = "", V = "", W = "";
		String equation = inEquation;
		while (!equation.contentEquals("")) {
			i = 0;
			repeat = true;
			token = "";
			while (repeat) {
				if (i == equation.length()) {
					repeat = false;
					postfix.enqueue(token);
				} else if (equation.charAt(i) >= '0' && equation.charAt(i) <= '9') {
					token = token + equation.charAt(i);
					i++;
				} else {
					if (!token.contentEquals(""))
						postfix.enqueue(token);
					repeat = false;
					token = "" + equation.charAt(i);
				}
			}
			repeat = true;
			if (token.equals("("))
				stack.push(token);
			else if (token.contentEquals(")")) {
				while (repeat) {
					U = stack.pop();
					if (U.equals("("))
						repeat = false;
					else {
						postfix.enqueue(U);
					}
				}
			} else if (token.equals("+") || token.equals("-") || token.equals("*") || token.equals("/")) {
				repeat = true;
				while (repeat) {
					if (stack.isEmpty() || stack.peek() == null) {
						stack.push(token);
						repeat = false;
					} else {
						V = stack.peek();
						if (V.equals("("))
							stack.push(token);
						else if ((V.contentEquals("*") || V.contentEquals("/"))
								&& (token.equals("+") || token.equals("-"))) {
							V = stack.pop();
							postfix.enqueue(V);
						} else {
							stack.push(token);
							repeat = false;
						}
					}
				}
			}
			if (i == equation.length())
				equation = "";
			else {
				equation = equation.substring(i + 1);
			}
		}
		while (stack.peek() != null) {
			W = stack.pop();
			postfix.enqueue(W);
		}
		stack.clear();
		while (!postfix.isEmpty()) {
			token = postfix.dequeue();
			if (token.charAt(0) >= '0' && token.charAt(0) <= '9') {
				stack.push(token);
			} else {
				switch (token) {
				case "+":
					partSum = Integer.parseInt(stack.pop()) + Integer.parseInt(stack.pop());
					stack.push("" + partSum);
					break;
				case "-":
					int term2 = Integer.parseInt(stack.pop());
					int term1 = Integer.parseInt(stack.pop());
					partSum = term1 - term2;
					stack.push("" + partSum);
					break;
				case "*":
					partSum = Integer.parseInt(stack.pop()) * Integer.parseInt(stack.pop());
					stack.push("" + partSum);
					break;
				case "/":
					int denom = Integer.parseInt(stack.pop());
					int numer = Integer.parseInt(stack.pop());
					partSum = numer / denom;
					stack.push("" + partSum);
					break;
				}
			}
		}
		String answer = stack.pop();
		return answer;
	}

	private void printUndoStack() {
		undo.printStack();
	}

	private void printRedoStack() {
		redo.printStack();
	}

	public static void main(String args[]) {
		ProjectFour pf = new ProjectFour();
		try {
			Scanner scan = new Scanner(new File("dictionary.txt"));
			while (scan.hasNextLine()) {
				dictionary.insert(scan.nextLine());
			}
			scan.close();
		} catch (FileNotFoundException e) {
			System.out.println("Dictionary not found. Check path: " + e);
		}
	}
}