This program was made via Eclipse. Everything should work properly. Just load up Eclipse, 
check your dictionary path, and run ProjectFour.java. Vertical and horizontal scroll bars 
have been added, as well as hot-key commands ctrl-Z(ctrl-Y) for quick undo(redo). A stackPrint 
function has been added to the menu options. This will print the current undo(redo) stack 
to the console in Eclipse. The equation solver's code is hot garbage, but fully functional,
as per project guidelines. Variables may take the form "a=3" or "varName=33333". Spell check works
as described in the assignment. A maximum of ten suggestions will pop up for selection by the user.
Select a button to change a word in the textArea. There are times when the spell checker will pop
behind the text editor. Make sure it is gone before assuming it has actually finished. I wasn't able
to figure out why it kept doing this. Undo(redo) will work on all equation solutions and spell checks.
Data structures used include Hash Tables, StackLists, QueueLists, and the use of Nodes.
Please do enjoy the hot garbage. I know I didn't.