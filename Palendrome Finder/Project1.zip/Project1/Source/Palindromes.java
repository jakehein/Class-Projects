package programone;
import java.util.*;
import java.io.*;

/**
 * @description This class determines the existence of palendromes by reading in from an input file 
 * 				named dictionary.txt and comparing the char elements at both ends of the read word.
 * 				If a palindrome is found, the word is printed to a file called output.txt.
 * 				Runtimes are given for each method.
 * @author Jacob Hein
 * @version 3/1/2019
 */
public class Palindromes {

	/**
	 * This method enqueues char elements from an input word parameter into the QueueList and
	 * returns the QueueList to the calling method.
	 * @param word is the word being passed into the method.
	 * @return queueList is the QueueList being returned to the calling method.
	 */
	public static QueueList palinCheckerQueueList(String word) {
		QueueList queueList = new QueueList();
		for(int i = 0; i < word.length(); i++) 
			queueList.enqueue(word.charAt(i));
		return queueList;
	}
	
	/**
	 * This method pushes char elements from an input word parameter into a StackArray and
	 * returns the StackArray to the calling method.
	 * @param word is the word being passed into the method.
	 * @return array is the StackArray being returned to the calling method.
	 */
	public static StackArray palinCheckerStackArray(String word) {
		StackArray array = new StackArray();
		for(int i = 0; i < word.length(); i++) 
			array.push(word.charAt(i));
		return array;
	}
	
	/**
	 * This method pushes char elements from an input word parameter into a StackList and returns
	 * the StackList to the calling method.
	 * @param word is the word being passed into the method.
	 * @return stackList is the StackList being returned to the calling method.
	 */
	public static StackList palinCheckerStackList(String word) {
		StackList stackList = new StackList();
		for(int i = 0; i < word.length(); i++) 
			stackList.push(word.charAt(i));
		return stackList;
	}
	
	/**
	 * The wordReader method does the majority of the work for the Palindromes class, creating a FileReader,
	 * PrintWriter, Scanner, and File to read in from. The method then calls some helper methods to parse out
	 * a word that's scanned in from the dictionary.txt file and enqueues/pushes the char elements into the 
	 * QueueList/StackArray/StackList classes. The method then dequeues/pops the elements off according to their
	 * class procedure and compares the returned char elements to see if the initial word scanned in is
	 * a palindrome, returning false if at any time there is a mismatch. If a palindrome is found, the word
	 * is then printed to a newline in an output.txt file. Appropriate catches are called and a finally block
	 * closes the appropriate functions.
	 */
	public static void wordReader() {
		FileReader inFile = null;
        PrintWriter palenPrinter = null;
        Scanner scan = null;
        QueueList queueList = new QueueList();
        StackArray stackArray = new StackArray();
        StackList stackList = new StackList();
        boolean isPalendrome = true;
        String word;
        try {
        	File file = new File("dictionary.txt");
        	inFile = new FileReader(file);
            palenPrinter = new PrintWriter("output.txt");
            scan = new Scanner(inFile);
            while (scan.hasNext())
                if (scan.hasNext()) {
                    word = scan.next();
                    queueList = palinCheckerQueueList(word);
                 	stackArray = palinCheckerStackArray(word);
                   	stackList = palinCheckerStackList(word);
                   	while(isPalendrome && queueList.size() > 0)
                   		if (queueList.dequeue() != stackArray.pop())
                   			isPalendrome = false;
                   	if (isPalendrome == true)
                   		palenPrinter.println(word);
                   	isPalendrome = true;
                }
        }
        catch (FileNotFoundException ex) {
            System.out.println("Access denied: " + ex + "\nCheck Files");
        }
        finally {
            if (scan != null)
                scan.close();
            if (palenPrinter != null)
                palenPrinter.close();
        }
	}
	/**
	 * Main method calls the wordReader class which does the main work of the Palindromes program.
	 * @param args is the unused command line argument parameter
	 */
	public static void main(String[] args) {
			wordReader();
	}
}
