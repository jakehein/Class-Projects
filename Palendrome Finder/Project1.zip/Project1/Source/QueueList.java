package programone;

/**
 * @description This class creates a QueueList based on the framework of a DoublyLinkedList
 * 				and a MyDoublyNode class. The user is enabled the ability to enqueue/dequeue
 * 				chars, check the list's size, and whether it is empty or not. Runtimes are
 * 				given for each method.
 * @author Jacob Hein
 * @version 3/1/2019
 */

public class QueueList {
	    
	private MyDoublyNode head;
	   
	/**
     * Constructor
     */
    public QueueList(){
        head = null;
    }
    
    /**
     * This method enqueues a parameter character at the end of the QueueList and links it to the
     * previous MyDoublyNode.
     * The runtime for this method is \theta(n), where n is the number of elements in a word
     * being enqueued.
     * @param x is the character being enqueued in the QueueList.
     */
    public  void enqueue(char x) {
    	MyDoublyNode insertMe = new MyDoublyNode(x, null, null);
        if(head==null)
            head = insertMe;
        else {
             MyDoublyNode current = head;
             while(current.getNext()!=null)
                 current = current.getNext();
             current.setNext(insertMe);
             insertMe.setPrevious(current);
        }
    }
    
    /**
     * This method dequeues the last element in the QueueList and returns the element being
     * dequeued to the user.
     * The runtime of this method is \theta(n), since it would be constant if not for the call to size(),
     * which runs through all the elements in the queue. 
     * @return returnChar is the char element being returned after being dequeued from the list.
     */
    public char dequeue() {
    	char returnChar;
    	MyDoublyNode deqChar;
    	int numElements = size();
    	if(numElements == 0)
            throw new RuntimeException("No elements in the queue");
        else {
            deqChar = head;
        	returnChar = deqChar.getData();
    		head = head.getNext();
    		if (head != null)
    			head.setPrevious(null);
        }
    	return returnChar;
    }
    
    /**
     * This method returns true or false depending on whether the QueueList is empty or not.
     * The runtime of this method is \theta(1), as it checks the head and nothing more.
     * @return returnEmpty is the value returned.
     */
    public boolean isEmpty() {
    	boolean returnEmpty = false;
    	if (head == null)
    		returnEmpty = true;
    	return returnEmpty;
    }
    
    /**
     * This method returns the number of elements currently being stored in the QueueList.
     * The runtime of this method is \theta(n), as it runs through all the elements being
     * stored and returns the number of elements present.
     * @return returnSize is the int number of elements currently being stored.
     */
    public int size() {
    	int returnSize = 0;
    	MyDoublyNode current = head;
    	while (current != null) {
    		current = current.getNext();
    		returnSize++;
    	}
    	return returnSize;
    }
}
