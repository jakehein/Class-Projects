package programone;

/**
 * @description This class creates a StackArray based on the framework of an ArrayList class.
 * 				It enables the user to push/pop char elements from the StackArray, resizing
 * 				accordingly, as well as determine the StackArray's size and emptiness. Runtimes
 * 				are given for each method.
 * @author Jacob Hein
 * @version 3/1/2019
 *
 */
public class StackArray {

	private char[] data;
    
	/**
     * Constructor
     */
	public StackArray(){
		data = new char[2];
	}
	
	/**
	 * This method pushes a char element onto the StackArray, resizing to twice the original
	 * capacity if capacity is reached when entering in a new element.
	 * The runtime of this method is \theta(n) as there is a call to size(), which runs in n time,
	 * and there is a for-loop which runs in n time. 
	 * @param x is the char element being pushed onto the StackArray.
	 */
	public void push(char x) {
		int num = size(), multByTwo = 2;
		if(num < data.length)
			data[num] = x;  
		else{
			char[] biggerArray = new char[data.length * multByTwo];
			for(int i = 0; i < data.length; i++)
				biggerArray[i] = data[i];
			System.out.println("The array is being resized due to it hitting capacity.");
			biggerArray[num] = x;
			data = biggerArray;
		}
	}
	
	/**
	 * This method pops elements off of the end of the StackArray using the size() method
	 * to find the most recently pushed element. The value of the popped element is
	 * then replaced with the null char '\u0000'.
	 * The runtime of this method is \theta(n) for the exact same reasons as the push method.
	 * @return returnChar is the character at data[index] being popped from the StackArray.
	 */
	public char pop() {
		int num = size(), index = num - 1, divideThree = 3, divideTwo = 2;
		char returnChar = data[index];
		data[index] = '\u0000';
		num--;
		if((num <= data.length / divideThree) && data.length > divideTwo) {
			char[] smallerArray = new char[data.length / divideTwo];
			for(int i = 0; i < smallerArray.length; i++)
				smallerArray[i] = data[i];
			System.out.println("The array is being resized to fit a smaller dataset.");
			data = smallerArray;
		}
		return returnChar;
	}
	
	/**
	 * This method returns true or false depending on whether the StackArray is empty or not.
	 * The runtime of this method is \theta(1), as it checks the first element and then ends.
	 * @return returnEmpty is the value being returned.
	 */
	public boolean isEmpty() {
		boolean returnEmpty = false;
		if (data[0] == '\u0000')
			returnEmpty = true;
		return returnEmpty;
	}
	
	/**
	 * This method returns the size of the StackArray based on the number of valid, non-null
	 * chars present.
	 * The runtime of this method is \theta(n), as it runs through all the elements in the array
	 * and returns the length of the array to the calling method.
	 * @return returnSize is the number of non-null chars present.
	 */
	public int size() {
    	int returnSize = 0;
    	int i = 0;
    	if(data[data.length - 1] == '\u0000')
    		while(data[i] != '\u0000') {
    			returnSize++;
    			i++;
    		} 
    	else {
    		returnSize = data.length;
    	}
    	return returnSize;
    }
}
