package programone;

/**
 * @description This class creates the framework of a MyNode, which will be used for the 
 * 				StackList class. MyNode objects contain char elements and a pointer
 * 				to their previous neighbor.
 * @author Jacob Hein
 * @version 3/1/2019
 */
public class MyNode {

	private char element;
    private MyNode next;
    
    /**
     * Constructor
     */
    public MyNode(){
        element = '\u0000';
        next = null;
    }
    
    /**
     * Constructor
     * @param data is the element being passed into the class.
     */
    public MyNode(char data){
        element = data;
    }
    
    /**
     * Constructor
     * @param data is the element being passed into the class.
     * @param next is the next MyNode object being pointed to by the current object.
     */
    public MyNode(char data, MyNode next){
        element = data;
        this.next = next;
    }
    
    /**
     * This method sets the next MyNode being pointed to by the current MyNode object.
     * @param next is the next MyNode being pointed to.
     */
    public void setNext(MyNode next){
        this.next = next;
    }
    
    /**
     * This method gets the next MyNode object currently being pointed at and returns it to the user.
     * @return is the next MyNode object being returned.
     */
    public MyNode getNext(){
        return next;
    }
    
    /**
     * This method sets the current value held by the current MyNode object.
     * @param data is the element being assigned to the current MyNode object.
     */
    public void setData(char data){
        element = data;
    }
    
    /**
     * This method gets the value being held by the current MyNode object and returns it to the user.
     * @return element is the char being returned to the user.
     */
    public char getData(){
        return element;
    }
}
