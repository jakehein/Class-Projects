/**
 * @description This method creates a MyLinkedList object capable of storing MyNodes of MyVertex objects.
 * @author Jacob Hein
 * 
 * @version 5/12/2019
 */
package project5;

public class MyLinkedList {
	private MyNode head, tail;
	private int size;

	public MyLinkedList() {
		head = null;
		tail = null;
		size = 0;
	}
	/**
	 * This method adds a MyVertex node to the current list.
	 * @param node is the node being added.
	 */
	public void add(MyVertex node) {
		MyNode temp = new MyNode(node);
		if (head == null) {
			head = temp;
			head.setData(node);
			tail = head;
			tail.setData(node);
		} else {
			tail.setNext(temp);
			temp.setPrevious(tail);
			tail = temp;
			tail.setData(node);
		}
		size++;
	}
	/**
	 * This method appends another MyLinkedList object to the current list.
	 * @param inList is the list being appended to the current list.
	 */
	public void append(MyLinkedList inList) {
		if (head == null) {
			head = inList.head;
			tail = inList.tail;
		} else {
			tail.setNext(inList.head);
			inList.head.setPrevious(tail);
			tail = inList.tail;
		}
		size += inList.size;
	}
	/**
	 * This method removes a MyVertex object from the current list.
	 * @param index is the index of the current object being removed.
	 * @return current.getData() is the data of the object being removed.
	 */
	public MyVertex remove(int index) {
		if (index >= size || index < 0)
			throw new RuntimeException("Index out of bounds");
		MyNode current = head;
		for (int i = 0; i < index; i++)
			current = current.getNext();
		if (current.getPrevious() != null)
			current.getPrevious().setNext(current.getNext());
		else {
			head = head.getNext();
			if (head != null)
				head.setPrevious(null);
		}
		if (current.getNext() != null)
			current.getNext().setPrevious(current.getPrevious());
		else {
			if (tail.getPrevious() != null)
				tail.getPrevious().setNext(null);
			tail = null;
		}
		size--;
		return current.getData();
	}
	/**
	 * This method returns a boolean value based on the existence of a value in the list.
	 * @param value is the value being searched for.
	 * @return true or false based on whether the object exists.
	 */
	public boolean contains(MyVertex value) {
		MyNode current = head;
		while (current != null) {
			if (current.getData().equals(value))
				return true;
			current = current.getNext();
		}
		return false;
	}
	/**
	 * This method returns the index of the searched for MyVertex object
	 * @param value is the object being searched for
	 * @return i is the index of the object being searched for.
	 */
	public int indexOf(MyVertex value) {
		MyNode current = head;
		int i = 0;
		while (current.getData() != value) {
			current = current.getNext();
			i++;
		}
		return i;
	}
	/**
	 * This method gets the node stored in the list at the given index.
	 * @param index is the location in the list of the stored node.
	 * @return current.getData() is the node's value stored at the index.
	 */
	public MyVertex get(int index) {
		if (index >= size || index < 0)
			throw new RuntimeException("Index out of bounds");
		MyNode current = head;
		for (int i = 0; i < index; i++)
			current = current.getNext();
		return current.getData();
	}
	/**
	 * This method returns the number of elements currently in the list.
	 * @return size is the size of the list.
	 */
	public int size() {
		return size;
	}
}
