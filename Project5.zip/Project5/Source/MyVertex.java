/**
 * @description This class creates a MyVertex object for the MyUndirected graph class.
 * @author Jacob Hein
 * 
 * @version 2/12/2019
 */
package project5;

public class MyVertex {

	private String vertString;
	private int inDegree;

	private MyHashMap edgeList;
	private MyHashMap revList;
	private MyIntHashMap edgeWeight;

	public MyVertex(String vertString) {
		this.vertString = vertString;
		inDegree = 0;
		edgeList = new MyHashMap();
		revList = new MyHashMap();
		edgeWeight = new MyIntHashMap();
	}
	/**
	 * This method sets InDegree.
	 */
	public void setInDegree() {
		int neighbors = edgeList.returnValues().length;
		inDegree = neighbors;
	}
	/**
	 * This method gets an int[] of all valueSet for edgeWeight
	 * @return edgeWeight.returnValues() is a valueSet
	 */
	public int[] getWeights() {
		return edgeWeight.returnValues();
	}
	/**
	 * This method gets a MyVertex[] of the edgeList's valueSet
	 * @return edgeList.returnValues() returns the edgeList valueSet
	 */
	public MyVertex[] getNeighbors() {
		return edgeList.returnValues();
	}
	/**
	 * This method gets a MyVertex[] of the revList's ValueSet
	 * @return revList.returnValues() returns the revList valueSet
	 */
	public MyVertex[] getRevNeighbors() {
		return revList.returnValues();
	}
	/**
	 * This decrements the neighboring vertices indegrees
	 */
	public void decrementNeighborsIndegrees() {
		for (MyVertex current : edgeList.returnValues())
			current.decrementInDegree();
	}
	/**
	 * none of these are used. Ignore them.
	 * @return
	 */
	public int getInDegree() {
		return inDegree;
	}
	/**
	 * I should just delete these.
	 */
	public void decrementInDegree() {
		inDegree--;
	}
	/**
	 * such a waste
	 */
	public void incrementInDegree() {
		inDegree++;
	}
	/**
	 * God, this is annoying
	 */
	public void iterateOverEdges() {
		for (MyVertex current : edgeList.returnValues())
			current.incrementInDegree();
	}
	/**
	 * This method determines the existence of an edge given a string key 
	 * @param other is the String being searched for
	 * @return true or false based on the existence of other
	 */
	public boolean containsEdge(String other) {
		for (String current : edgeList.returnKeys())
			if (current != null && current.equals(other))
				return true;
		return false;
	}
	/**
	 * returns a custom string representation of the MyVertex class
	 */
	public String toString() {
		return vertString;
	}
	/**
	 * This method adds an edge to the edgeList
	 * @param other is the MyVertex being added
	 */
	public void addEdge(MyVertex other) {
		edgeList.insert(other.getVertString(), other);
	}
	/**
	 * Ignore this one
	 * @param other
	 */
	public void revEdge(MyVertex other) {
		revList.insert(other.getVertString(), other);
	}
	/**
	 * This method adds an edge weight to the object's edgeWeight list
	 * @param other is the object being added to the list
	 * @param weight is the weight being added to the list
	 */
	public void addEdgeWeight(MyVertex other, int weight) {
		edgeWeight.insert(other.getVertString(), weight);
	}
	/**
	 * This method gets the edge weight of a specific key in the edgeWeight list.
	 * @param other is the MyVertex being searched for
	 * @return edgeWeight being returned
	 */
	public int getEdgeWeight(MyVertex other) {
		return edgeWeight.containsKey(other) ? edgeWeight.get(other) : -1;
	}
	/**
	 * This method gets the string value of the MyVertex object
	 * @return vertString value
	 */
	public String getVertString() {
		return vertString;
	}
}
