/**
 * @description This program reads in two input files "input1.txt" and "input2.txt" from the user and
 * 				executes a set of functions accordingly.
 * 				The "Facebook" problem creates a graph of friend vertices and finds a smallest possible
 * 				set of friends that can see all other friends.
 * 				The "campus delivery" problem creates a connected graph of building vertices and finds
 * 				the fastest route that the user can take to visit every building.
 * 				Both methods have terrible runtimes, although I did find a way to run problem 2 in
 * 				\theta((n^2)*(2^n)) instead of \theta(n!), but it required a whole lot of work to understand.
 * 				Problem 2 can do about 14 verts in 10 mins. Problem 1 seemed harder to actually find a cap for.
 * @author Jacob Hein
 * 
 * @verson 5/12/2019
 */
package project5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

public class Project5 {
	/**
	 * private buildingArray method that stores strings
	 */
	private static String[] buildingArray;
	/**
	 * This method reads in the file "input2.txt" and creates an undirected graph of buildings. 
	 * Two scanners are used, one to read in the building vertices, one to read in the edge costs.
	 * @return graph of buildings with associated edge costs and other relevant information.
	 */
	private static MyUndirectedGraph populateBuildings() {
		MyUndirectedGraph graph = new MyUndirectedGraph();
		StackArray buildings = new StackArray();
		int i = 0, j;
		boolean first = true;
		try {
			Scanner scan = new Scanner(new File("input2.txt"));
			Scanner stringScan = null;
			String buildingVert;
			while (scan.hasNextLine()) {
				String line = scan.nextLine();
				stringScan = new Scanner(line);
				buildingVert = stringScan.next();
				buildings.push(buildingVert);
				graph.insertVertex(buildingVert);
				if (first) {
					first = false;
					graph.setStartVertex(buildingVert);
				}
			}
			buildingArray = buildings.toArray();
			scan = new Scanner(new File("input2.txt"));
			while (scan.hasNextLine()) {
				j = i;
				String line = scan.nextLine();
				line = line.substring(line.indexOf(" ") + 2);
				stringScan = new Scanner(line);
				while (stringScan.hasNext()) {
					j++;
					int token = stringScan.nextInt();
					graph.insertEdge(buildingArray[i], buildingArray[j], token);
				}
				i++;
			}
			scan.close();
			stringScan.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found. Check path for input2: " + e);
		}
		return graph;
	}
	/**
	 * This method reads in the file "input1.txt" and creates an undirected graph of friend vertices. 
	 * Two scanners are used for this file, one to read in the lines, and another for creating tokens
	 * out of each line. 
	 * @return graph of friend vertices with associated edge lists and other relevant information.
	 */
	private static MyUndirectedGraph populateGraph() {
		MyUndirectedGraph graph = new MyUndirectedGraph();
		try {
			Scanner scan = new Scanner(new File("input1.txt"));
			Scanner stringScan = null;
			boolean first;
			String vert1;
			while (scan.hasNextLine()) {
				String line = scan.nextLine();
				stringScan = new Scanner(line);
				first = true;
				vert1 = "";
				while (stringScan.hasNext()) {
					String token = stringScan.next();
					if (token.contentEquals("-"))
						first = false;
					else if (first) {
						graph.insertVertex(token);
						vert1 = token;
					} else if (!first) {
						graph.insertVertex(token);
						graph.insertEdge(vert1, token);
					}
				}
			}
			scan.close();
			stringScan.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found. Check path for input1: " + e);
		}
		return graph;
	}

	/**
	 * This method starts the recursive process of finding all possible combinations of friends
	 * needed to see all friends to cover all vertices in the graph.
	 * @param first is the first index in the array being selected.
	 * @param second is the index being gone to in the recursive call. 
	 * @return returns a combination of arrays of a given length specified by @param second
	 */
	public static StackArray2D recComs(int first, int second) {
		StackArray2D comboArrays = new StackArray2D();
		int[] arrayRec = new int[second];
		int arrayRecTwo = first - 1;
		comboBreaker(comboArrays, arrayRec, 0, arrayRecTwo, 0);
		return comboArrays;
	}
	/**
	 * This method does the majority of the heavy lifting for the friend vertices recursion.
	 * @param comboArrays is the 2D array that's being added to.
	 * @param array is the current array being gone over.
	 * @param first is the array location being incremented each iteration. This helps create array combos.
	 * @param last is the end of the particular array being gone over.
	 * @param index is the index of the array being looked when creating combos.
	 */
	private static void comboBreaker(StackArray2D comboArrays, int[] array, int first, int last, int index) {
		if (index == array.length) {
			int[] comboClone = array.clone();
			comboArrays.insert(comboClone);
		} else if (first <= last) {
			array[index] = first;
			comboBreaker(comboArrays, array, first + 1, last, index + 1);
			comboBreaker(comboArrays, array, first + 1, last, index);
		}
	}
	/**
	 * This method returns a MyVertex[] containing the smallest possible friend group able to
	 * cover all the vertices of a particular graph. It calls on recursive methods to find this
	 * group of vertices, and then it checks a method containing a list of all vertices to see
	 * if all vertices have been covered by each iteration of vertex combos. The first instance
	 * of a vertex combo that returns positive for full coverage is returned to the calling method.
	 * @param graph is the undirected graph containing all friend vertices and their associated edge lists.
	 * @param vertValues is the list of all values located in the vertices hashMap of the graph.
	 * @return currentVerts is the list of vertices necessary for covering the whole graph.
	 * 			If nothing is returned, an error has occured, although I have yet to see this happen.
	 */
	public static MyVertex[] thisIsDumbAndIHateItButIUnderstandTheBenefitsOfDoingThisExercise(MyUndirectedGraph graph,
			MyVertex[] vertValues) {
		int counter;
		for (int i = 2; i <= vertValues.length; i++) {
			StackArray2D vertArray = recComs(vertValues.length, i);
			for (int j = 0; j < vertArray.size(); j++) {
				MyVertex[] vertNeighbors = new MyVertex[vertValues.length * i];
				counter = 0;
				int[] current = vertArray.getInts(j);
				MyVertex[] currentVerts = new MyVertex[current.length];
				for (int k = 0; k < current.length; k++) {
					MyVertex vert = vertValues[current[k]];
					currentVerts[k] = vert;
					vertNeighbors[counter] = vert;
					MyVertex[] neighbors = vert.getNeighbors();
					counter++;
					for (int l = 0; l < neighbors.length; l++) {
						vertNeighbors[counter] = neighbors[l];
						counter++;
					}
				}
				if (vertexCover(vertNeighbors, vertValues))
					return currentVerts;
			}
		}
		return new MyVertex[0];
	}
	/**
	 * This method checks to see that all the vertices of the graph have been covered by the input
	 * vertices list.
	 * @param inVertList is the vertices list being iterated over and checked.
	 * @param vertList is the list of all vertices in the graph that need to be seen.
	 * @return true or false depending on whether the graph is completely covered.
	 */
	public static boolean vertexCover(MyVertex[] inVertList, MyVertex[] vertList) {
		for (int i = 0; i < vertList.length; i++) {
			MyVertex vertex = vertList[i];
			if (vertex != null)
				if (!availableSpots(vertex, inVertList))
					return false;
		}
		return true;
	}
	/**
	 * This method helps the vertexCover method check to make sure all vertices are covered in the graph. 
	 * @param inVertex is the vertex currently being checked against.
	 * @param inVertList is the list of all vertices in the graph that need to be seen.
	 * @return true or false depending on whether the graph is completely covered.
	 */
	public static boolean availableSpots(MyVertex inVertex, MyVertex[] inVertList) {
		String vertex = inVertex.getVertString();
		String vertCompare;
		for (int i = 0; i < inVertList.length; i++)
			if (inVertList[i] != null) {
				vertCompare = inVertList[i].getVertString();
				if (vertex.equals(vertCompare))
					return true;
			}
		return false;
	}
	/**
	 * Main method runs all code for Problem 1 and Problem 2.
	 * @param args
	 */
	public static void main(String[] args) {
		MyUndirectedGraph graph = populateGraph();
		MyUndirectedGraph buildingGraph = populateBuildings();
		MyVertex[] vertValues = graph.returnValues();
		MyVertex[] facebookProblem = thisIsDumbAndIHateItButIUnderstandTheBenefitsOfDoingThisExercise(graph,
				vertValues);
		if (facebookProblem.length == 0)
			throw new RuntimeException("Problem occured when running problem 1. Check input.");
		System.out.println("Problem 1: \n" + Arrays.deepToString(facebookProblem) + "\n\nProblem 2: ");
		buildingGraph.shortestPath();
	}
}
