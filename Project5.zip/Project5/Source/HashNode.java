package project5;

public class HashNode {
	private int key;
	//private String value;
	private MyVertex value;
	
	
	public HashNode(MyVertex inValue) {//String inValue) {
		key = Math.abs(inValue.getVertString().hashCode());
		value = inValue;
	}
	
	//public void setKey(String inValue) {
	//	key = Math.abs(inValue.hashCode());
	//}
	
	//public void setValue(String inValue) {
	//	value = inValue;
	//}
	public void clear() {
		value = null;
	}
	public int getKey() {
		return key;
	}
	
	public MyVertex getValue(){//String getValue() {
		return value;
	}
}
