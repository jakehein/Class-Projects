/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project5;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;
import java.util.function.IntFunction;

/**
 *
 * @author krohne
 */
public class MyDirectedGraph {
    //private HashMap<String, MyVertex> vertices;
    private MyHashMap vertices;
    //private HashMap<String, MyVertex> reverseBFS;
    private MyHashMap reverseBFS;
    //private HashMap<MyVertex, Boolean> BFS;
    
    
    public MyDirectedGraph(){
        vertices = new MyHashMap();    
        //BFS = new HashMap();
        reverseBFS = new MyHashMap();
    }
    
    //public void topologicalSort(){
        //calculate inDegree
        //\Theta(V+E)
        //Collection<MyVertex> allValues = vertices.returnValues();
    //    for(MyVertex current : vertices.returnValues()){
    //        current.iterateOverEdges();
    //   }
        
    //    Stack<MyVertex> zeroInDegree = new Stack<>();
        
        //O(V)
        //find a vertex with inDegree of 0
    //    for(MyVertex current : allValues){
    //        if(current.getInDegree() == 0){
    //            zeroInDegree.push(current);
    //        }
    //    }
        
        //O(V+E)
    //    while(!zeroInDegree.empty()){
    //        MyVertex current = zeroInDegree.pop();
    //        System.out.print(current+" ");
    //        current.decrementNeighborsIndegrees();
            //check neighbors, if their inDegree is 0, push onto stack
    //        Collection<MyVertex> currentNeighbors = current.getNeighbors();
    //        for(MyVertex currentNeighbor : currentNeighbors){
    //            if(currentNeighbor.getInDegree() == 0){
    //                zeroInDegree.push(currentNeighbor);
    //            }
    //        }
    //    }
    //}
    
    private boolean exists(String inKey){
    	if(vertices.search(inKey) != null && vertices.search(inKey).getVertString().equals(inKey))
        	return true;
        else{
        	return false; //vertices.containsKey(vertString);
        }
    	//return vertices.containsKey(vertString);
        /*for(MyVertex current : vertices){
            if(number == current.getNumber()){
                return true;
            }
        }
        return false;*/
    }
    
    public int numVerts() {
    	return vertices.size();
    }
    
    public void printData(){
        for(MyVertex current : vertices.returnValues()){
            System.out.println(current);
        }
        System.out.println(numVerts());
    }
    
	/*public boolean connected() {
    	boolean isConnected = false;
    	//Collection<MyVertex> allValues = vertices.returnValues();
    	ArrayList<MyVertex> array = new ArrayList<MyVertex>();
    	Queue<MyVertex> queue = new LinkedList<MyVertex>();
    	for(MyVertex current : vertices.returnValues()) {
    		array.add(current);
    		BFS.put(current, false);
    		MyVertex temp = new MyVertex(current.getVertString());
            reverseBFS.put(current.getVertString(), temp);
            //System.out.println(reverseBFS);
    	}
    	
    	MyVertex s = array.get(0);
    	//System.out.println(s.getNeighbors());
    	//System.out.println(s.getRevNeighbors());
    	BFS.replace(s, true);
    	queue.add(s);
    	//System.out.println("queue" + queue.toString());
    	while (!queue.isEmpty()) {
    		MyVertex v = queue.poll();
    		for(MyVertex u : v.getNeighbors()) {
    			if (u == null) {
    				return false;
    			}
    			if (BFS.get(u) == false) {
    				BFS.put(u, true);
    				queue.add(u);
    				//System.out.println("U" + u + "V" + v);
    				MyVertex firstVertex = reverseBFS.get(u.getVertString());
    				//System.out.println("firstV"+firstVertex.getNumber());
                    MyVertex secondVertex = reverseBFS.get(v.getVertString());
                    //System.out.println("secondV"+secondVertex.getNumber());
                    firstVertex.revEdge(secondVertex);
                    //System.out.println();
                    //System.out.println("u" + u.getNumber());
                    //System.out.println("v" + v.getNumber());
                    //System.out.println(reverseBFS.toString());
    			}
    			else if(!u.containsEdge(v.getVertString())) {
    				MyVertex firstVertex = reverseBFS.get(u.getVertString());
    				//System.out.println("firstV"+firstVertex.getNumber());
                    MyVertex secondVertex = reverseBFS.get(v.getVertString());
                    //System.out.println("secondV"+secondVertex.getNumber());
                    firstVertex.revEdge(secondVertex);
                    //System.out.println();
    			}
    		}
    	}
    	//System.out.println(BFS);
    	//System.out.println(BFS.values());
    	//System.out.println(vertices.toString());
    	queue.clear();
    	BFS.clear();
    	Collection<MyVertex> reverseValues = reverseBFS.values();
    	ArrayList<MyVertex> reverseArray = new ArrayList<MyVertex>();
    	for(MyVertex current : reverseValues) {
    		BFS.put(current, false);
    		reverseArray.add(current);
    	}
    	//System.out.println("BFS Values" + reverseBFS.values());
    	//System.out.println("BFS" + reverseBFS.toString());
    	s = reverseArray.get(0);
    	BFS.replace(s, true);
    	queue.add(s);
    	//System.out.println(s.toString());
    	//System.out.println(queue.toString());
    	while (!queue.isEmpty()) {
    		//System.out.println("Entered");
    		MyVertex v = queue.poll();
    		//System.out.println("V:" + v.getRevNeighbors());
    		for(MyVertex u : v.getRevNeighbors()) {
				//System.out.println("U" + u + "V" + v);
				//System.out.println("Entered again");
    			if (u == null) {
    				return false;
    			}
    			if (BFS.get(u) == false) {
    				BFS.put(u, true);
    				queue.add(u);
    				//System.out.println("U" + u + "V" + v);

    			}
    		}
    	}
    	//System.out.println(BFS.values());
    	if (BFS.containsValue(false)) {
    		isConnected = false;
    	} else {
    		isConnected = true;
    	}
    	return isConnected;
    }
    */
    
    /*
    public void insertEdge(String src, String dest, double weight) {
        if(exists(src) && exists(dest)){
        	if(!vertices.get(src).containsEdge(dest)){                        
                
        	MyVertex firstVertex = vertices.get(src);
            MyVertex secondVertex = vertices.get(dest);

            firstVertex.addEdge(secondVertex);
            firstVertex.addEdgeWeight(secondVertex, weight);;
        	} 
        } else{
            throw new RuntimeException("some vertex doesn't exist");
        }
    }
    */
    
    public void insertEdge(String first, String second){
        if(exists(first) && exists(second)){
            //both vertices exist
            
            //check if the edge exists
            if(!vertices.search(first).containsEdge(second)){                        
                //getting the vertex for first and second
                MyVertex firstVertex = vertices.search(first);
                MyVertex secondVertex = vertices.search(second);
                /*for(MyVertex current : vertices){
                    if(current.getNumber() == first){
                        firstVertex = current;
                    } else if(current.getNumber() == second){
                        secondVertex = current;
                    }
                }*/
                //add edge to graph
                firstVertex.addEdge(secondVertex);
            }
        } else{
            throw new RuntimeException("some vertex doesn't exist");
        }
        
    }
    
    public void insertVertex(String inKey){
        //check to see if number already exists in vertex list
        if(exists(inKey)){
            return;
        	//throw new RuntimeException(vertString+" already exists");
        } else{
            //number doesn't exist
            MyVertex temp = new MyVertex(inKey);
            vertices.insert(inKey, temp);
        }
    }
}
