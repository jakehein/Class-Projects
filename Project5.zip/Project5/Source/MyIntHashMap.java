/**
 * @Description This class creates a hashMap storing String keys and int values. This will be used for 
 * 				storing edge weights. 
 * @author Jacob Hein
 * 
 * @verson 5/12/2019

 */
package project5;

public class MyIntHashMap {
	private String[] key;
	private int[] value;
	private float loadFactor;
	private int numElements;

	public MyIntHashMap() {
		key = new String[11];
		value = new int[11];
		numElements = 0;
		loadFactor = (float) numElements / key.length;
	}
	/**
	 * This method returns the number of elements stored in the hashMap
	 * @return numElements
	 */
	public int size() {
		return numElements;
	}
	/**
	 * This method clears the hashMap by instantiating a new hashMap
	 */
	public void clear() {
		key = new String[11];
		value = new int[11];
		numElements = 0;
		loadFactor = (float) numElements / key.length;
	}
	/**
	 * This method rehashes the hashMap once the table hits its loadFactor
	 * @param primeLength is the length of the new hashMap determined by getting the next largest
	 * 		prime number after the previous prime length of the last map's length.
	 */
	public void rehash(int primeLength) {
		String[] bigStrTable = new String[primeLength];
		int[] bigVertTable = new int[primeLength];
		int iElements = numElements;
		int count = 0;
		while (iElements > 0) {
			if (key[count] != null) {
				String word = key[count];
				int vert = value[count];
				int slot = Math.abs(word.hashCode()) % bigStrTable.length;
				int i = 0;
				int j = slot + (int) Math.pow(i, 2);
				while (bigStrTable[j] != null) {
					i++;
					j = (slot + (int) Math.pow(i, 2)) % bigStrTable.length;
				}
				bigStrTable[j] = word;
				bigVertTable[j] = vert;
				iElements--;
			}
			count++;
		}
		key = bigStrTable;
		value = bigVertTable;
		updateLoadFactor();
	}
	/**
	 * This method updates the loadFactor of the map. If the loadFactor hits .5, rehashing is performed.
	 */
	public void updateLoadFactor() {
		loadFactor = (float) numElements / key.length;
		if (loadFactor >= .5)
			nextPrime(key.length);
	}
	/**
	 * This method finds the next largest prime number after the current prime number being used for the
	 * current table's length.
	 * @param inNumber is the current table's length
	 */
	public void nextPrime(int inNumber) {
		int prime = (inNumber << 1) + 1;
		for (int i = 3; i < prime; i++)
			if (prime % i == 0) {
				prime = prime + 2;
				i = 3;
			}
		rehash(prime);
	}
	/**
	 * This method inserts a key and its associated value into the hashMap then updates the loadFactor.
	 * @param inKey is the key being added.
	 * @param inValue is the value being added.
	 */
	public void insert(String inKey, int inValue) {
		String word = inKey;
		int slot = Math.abs(word.hashCode()) % key.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		while (key[j] != null) {
			if (value[j] == (inValue))
				return;
			i++;
			j = (slot + (int) Math.pow(i, 2)) % key.length;
		}
		key[j] = inKey;
		value[j] = inValue;
		numElements++;
		updateLoadFactor();
	}
	/**
	 * This method returns a String of the hashMap.
	 */
	@Override
	public String toString() {
		String string = "Keys: ";
		for (String current : key)
			if (current != null)
				string = string + current + "\n";
		string = string + "\nValues: ";
		for (int current : value)
			if (current != '\0')
				string = string + current + "\n";
		return string;
	}
	/**
	 * This method prints the hashMap.
	 */
	public void printHashMap() {
		System.out.print("[");
		for (String current : key)
			if (current != null)
				System.out.print(current + ", ");
		System.out.print("]");
	}
	/**
	 * This method returns a String[] of the keys in the hashMap.
	 * @return returnArray is the array of keys being returned.
	 */
	public String[] returnKeys() {
		String[] returnArray = new String[numElements];
		int i = 0;
		int count = 0;
		while (i < numElements) {
			if (key[count] != null) {
				returnArray[i] = key[count];
				i++;
			}
			count++;
		}
		return returnArray;
	}
	/**
	 * This method returns a int[] of the values in the hashMap.
	 * @return returnArray is the array of values being returned.
	 */
	public int[] returnValues() {
		int[] returnArray = new int[numElements];
		int i = 0;
		int count = 0;
		while (i < numElements) {
			if (value[count] != '\0') {
				returnArray[i] = value[count];
				i++;
			}
			count++;
		}
		return returnArray;
	}
	/**
	 * This method removes a key and value from the hashMap.
	 * @param inKey is the key of the object being removed.
	 */
	public void remove(String inKey) {
		int hashKey = Math.abs(inKey.hashCode());
		int slot = hashKey % key.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		while (key[j] != null) {
			if (key[j].equals(inKey)) {
				key[j] = null;
				value[j] = '\0';
			}
			i++;
			j = (slot + (int) Math.pow(i, 2)) % key.length;
		}
		numElements--;
	}
	/**
	 * This method determines if the hashMap contains a specific key and returns true if so.
	 * @param inKey is the key being searched for.
	 * @return true or false depending on the state of the key.
	 */
	public boolean containsKey(MyVertex inKey) {
		return indexOf(inKey.getVertString()) != -1;
	}
	/**
	 * This method finds the index of a key in the hashMap and returns that index.
	 * @param inKey is the key being searched for
	 * @return j is the index being returned. -1 is returned if no key is found.
	 */
	private int indexOf(String inKey) {
		int hashKey = Math.abs(inKey.hashCode());
		int slot = hashKey % key.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		while (key[j] != null) {
			if (key[j].equals(inKey))
				return j;
			i++;
			j = (slot + (int) Math.pow(i, 2)) % key.length;
		}
		return -1;
	}
	/**
	 * This method gets the int value of a MyVertex object's inKey.
	 * @param inKey is the key being searched for.
	 * @return value[index] is the integer being returned.
	 */
	public int get(MyVertex inKey) {
		int index = indexOf(inKey.getVertString());
		if (index == -1)
			throw new RuntimeException("This isn't a key, bruh");
		return value[index];
	}
	/**
	 * This method searches for an integer by its associated key and returns the number.
	 * @param inKey is the key of the integer.
	 * @return value[j] is the value being returned.
	 */
	public int search(String inKey) {
		int hashKey = Math.abs(inKey.hashCode());
		int slot = hashKey % key.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		while (key[j] != null) {
			if (key[j].equals(inKey))
				return value[j];
			i++;
			j = (slot + (int) Math.pow(i, 2)) % key.length;
		}
		return -1;
	}
}
