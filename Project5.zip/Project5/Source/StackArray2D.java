/**
 * @description This class creates a 2D int arrayList. Should probably change the name, but
 * 				it was modified from the StackArray class made in project1.
 * @author Jacob Hein
 * 
 * @version 2/12/2019
 */
package project5;

public class StackArray2D {

	private int[][] data;

	public StackArray2D() {
		data = new int[2][];
	}
	/**
	 * This method inserts a value into the array
	 * @param x
	 */
	public void insert(int[] x) {
		int num = size(), multByTwo = 2;
		if (num < data.length)
			data[num] = x;
		else {
			int[][] biggerArray = new int[data.length * multByTwo][];
			for (int i = 0; i < data.length; i++)
				biggerArray[i] = data[i];
			biggerArray[num] = x;
			data = biggerArray;
		}
	}
	/**
	 * This method removes an element from the array at a given index
	 * @param index
	 */
	public void remove(int index) {
		int num = size();
		for (int i = index; i < num; i++)
			data[i] = data[i + 1];
	}
	/**
	 * This method returns an int[] for the given index in the 2D array
	 * @param index
	 * @return
	 */
	public int[] getInts(int index) {
		if (index < data.length)
			return data[index];
		return null;
	}
	/**
	 * determines the emptiness of the array
	 * @return
	 */
	public boolean isEmpty() {
		boolean returnEmpty = false;
		if (data[0] == null)
			returnEmpty = true;
		return returnEmpty;
	}
	/**
	 * returns the number of elements in the array
	 * @return
	 */
	public int size() {
		int returnSize = 0;
		int i = 0;
		if (data[data.length - 1] == null)
			while (data[i] != null) {
				returnSize++;
				i++;
			}
		else
			returnSize = data.length;
		return returnSize;
	}
}
