/**
 * @description This class creates the MyUndirectedGraph objects being traversed for this assignment.
 * 				The graph contains a hashMap of vertices, a starting vertex for problem 2, and methods
 * 				for finding information about the graph.
 * @author Jacob Hein
 * 
 * @version 2/12/2019
 */
package project5;

public class MyUndirectedGraph {
	private MyHashMap vertices;
	private MyVertex start;

	public MyUndirectedGraph() {
		vertices = new MyHashMap();
	}
	/**
	 * This method sets the starting vertex for problem 2's graph traversal
	 * @param start is the starting vertex for future traversal.
	 */
	public void setStartVertex(String start) {
		this.start = vertices.search(start);
	}
	/**
	 * This method returns a String[] of the vertices hashMap's keys
	 * @return vertices.returnKeys() is the returned keySet
	 */
	public String[] returnKeys() {
		return vertices.returnKeys();
	}
	/**
	 * This method returns a MyVertex[] of the vertices hashMap's values
	 * @return vertices.returnValues() is the returned valueSet
	 */
	public MyVertex[] returnValues() {
		return vertices.returnValues();
	}
	/**
	 * This method returns the number of vertices currently in the graph
	 * @return vertices.size() is the number of vertices being returned
	 */
	public int numVerts() {
		return vertices.size();
	}
	/**
	 * This method returns a boolean value depending on the existence of a given inKey in the graph.
	 * @param inKey is the key being searched for in the graph's hashMap
	 * @return true or false depending on the key's existence in the graph's hashMap
	 */
	private boolean exists(String inKey) {
		if (vertices.search(inKey) != null && vertices.search(inKey).getVertString().equals(inKey))
			return true;
		else
			return false;
	}
	/**
	 * This method prints the graph's values and the number of values in the graph.
	 */
	public void printData() {
		for (MyVertex current : vertices.returnValues())
			System.out.println(current);
		System.out.println(numVerts());
	}
	/**
	 * This method finds the shortest path connecting all vertices through recursive calls and the use
	 * of a Path MyLinkedList. The shortest cycle is printed to the console with its total edge cost.
	 */
	public void shortestPath() {
		MyVertex[] verts = vertices.returnValues();
		Path shortestPath = shortestPath(verts, start, start);
		System.out.println("End Cycle: ");
		while (shortestPath.getPath().size() > 0) {
			System.out.print(shortestPath.getPath().remove(0).getVertString());
			if (shortestPath.getPath().size() != 0)
				System.out.print(" --> ");
		}
		System.out.println("\nTotal: " + shortestPath.getTime());
	}
	/**
	 * This method recursively finds the shortest edge cost to go to every MyVertex object in one cycle.
	 * @param remaining is the remaining vertices needed to be traversed.
	 * @param current is the current vertex in traversal.
	 * @param start is the starting vertex that will eventually be returned to.
	 * @return currentPath is the current path being added recursively to form the total cycle's path.
	 */
	public Path shortestPath(MyVertex[] remaining, MyVertex current, MyVertex start) {
		MyVertex[] newRemaining = new MyVertex[remaining.length - 1];
		Path currentPath = new Path();
		currentPath.getPath().add(current);
		Path currentShortestPath = null;
		if (remaining.length == 1) {
			currentPath.setTime(current.getEdgeWeight(start));
			currentPath.getPath().add(start);
			return currentPath;
		}
		int count = 0;
		for (int i = 0; i < remaining.length; i++)
			if (remaining[i] != current)
				newRemaining[count++] = remaining[i];
		for (int i = 0; i < newRemaining.length; i++) {
			Path temp = shortestPath(newRemaining, newRemaining[i], start);
			temp.setTime(temp.getTime() + current.getEdgeWeight(newRemaining[i]));
			if (currentShortestPath == null || currentShortestPath.getTime() > temp.getTime())
				currentShortestPath = temp;
		}
		currentPath.setTime(currentShortestPath.getTime());
		currentPath.getPath().append(currentShortestPath.getPath());
		return currentPath;
	}
	/**
	 * This method inserts an weighted edge.
	 * @param first is the String of a vertex being connected.
	 * @param second is the String of a vertex being connected.
	 * @param weight is the integer cost of the vertex edge connection.
	 */
	public void insertEdge(String first, String second, int weight) {
		if (exists(first) && exists(second))
			if (!vertices.search(first).containsEdge(second)) {
				MyVertex firstVertex = vertices.search(first);
				MyVertex secondVertex = vertices.search(second);
				firstVertex.addEdge(secondVertex);
				secondVertex.addEdge(firstVertex);
				firstVertex.addEdgeWeight(secondVertex, weight);
				secondVertex.addEdgeWeight(firstVertex, weight);
			} else
				throw new RuntimeException("some vertex doesn't exist");
	}
	/**
	 * This method inserts an unweighted edge into the graph.
	 * @param first is the String of a vertex being connected.
	 * @param second is the String of a vertex being connected.
	 */
	public void insertEdge(String first, String second) {
		if (exists(first) && exists(second))
			if (!vertices.search(first).containsEdge(second)) {
				MyVertex firstVertex = vertices.search(first);
				MyVertex secondVertex = vertices.search(second);
				firstVertex.addEdge(secondVertex);
				secondVertex.addEdge(firstVertex);
			} else
				throw new RuntimeException("some vertex doesn't exist");
	}
	/**
	 * This method inserts a vertex into the graph.
	 * @param inKey is the key being inserted into the graph's HashMap.
	 */
	public void insertVertex(String inKey) {
		if (exists(inKey))
			return;
		else {
			MyVertex temp = new MyVertex(inKey);
			vertices.insert(inKey, temp);
		}
	}
}
