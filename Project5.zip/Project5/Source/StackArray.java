/**
 * @description This class creates an arrayList of string data. Should probably change the name, but
 * 				it was modified from the StackArray class made in project1.
 * @author Jacob Hein
 * 
 * @version 2/12/2019
 */
package project5;

public class StackArray {

	private String[] data;

	public StackArray() {
		data = new String[2];
	}
	/**
	 * This method returns the array object as a String[]
	 * @return
	 */
	public String[] toArray() {
		String[] returnArray = new String[size()];
		int i = 0;
		while (data[i] != null) {
			returnArray[i] = data[i];
			i++;
		}
		return returnArray;
	}
	/**
	 * This method adds values onto the array
	 * @param x
	 */
	public void push(String x) {
		int num = size(), multByTwo = 2;
		if (num < data.length)
			data[num] = x;
		else {
			String[] biggerArray = new String[data.length * multByTwo];
			for (int i = 0; i < data.length; i++)
				biggerArray[i] = data[i];
			biggerArray[num] = x;
			data = biggerArray;
		}
	}
	/**
	 * This method removes values from the array and returns them
	 * @return
	 */
	public String pop() {
		int num = size(), index = num - 1, divideThree = 3, divideTwo = 2;
		String returnStr = data[index];
		data[index] = null;
		num--;
		if ((num <= data.length / divideThree) && data.length > divideTwo) {
			String[] smallerArray = new String[data.length / divideTwo];
			for (int i = 0; i < smallerArray.length; i++)
				smallerArray[i] = data[i];
			data = smallerArray;
		}
		return returnStr;
	}
	/**
	 * This method checks the state of the array, returning true if empty
	 * @return
	 */
	public boolean isEmpty() {
		boolean returnEmpty = false;
		if (data[0] == null)
			returnEmpty = true;
		return returnEmpty;
	}
	/**
	 * This method returns the number of elements currently in the array
	 * @return
	 */
	public int size() {
		int returnSize = 0;
		int i = 0;
		if (data[data.length - 1] == null)
			while (data[i] != null) {
				returnSize++;
				i++;
			}
		else
			returnSize = data.length;
		return returnSize;
	}
}
