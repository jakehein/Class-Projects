/**
 * @description This class creates MyNode objects to be stored in a MyLinkedList.
 * @author Jacob Hein
 * 
 * @version 2/12/2019
 */
package project5;

public class MyNode {
	private MyVertex node;
	private MyNode next, previous;

	public MyNode(MyVertex inNode) {
		node = inNode;
		next = null;
		previous = null;
	}
	/**
	 * This method sets the data of the MyNode
	 * @param in is the MyVertex being added 
	 */
	public void setData(MyVertex in) {
		node = in;
	}
	/**
	 * This method gets the data of the MyNode
	 */
	public MyVertex getData() {
		return node;
	}
	/**
	 * This method sets the data of the next MyNode
	 * @param in is the MyNode being added 
	 */
	public void setNext(MyNode in) {
		next = in;
	}
	/**
	 * This method sets the data of the previous MyNode
	 * @param in is the MyNode being added 
	 */
	public void setPrevious(MyNode in) {
		previous = in;
	}
	/**
	 * This method gets the data of the next MyNode
	 */
	public MyNode getNext() {
		return next;
	}
	/**
	 * This method gets the data of the previous MyNode
	 */
	public MyNode getPrevious() {
		return previous;
	}
}
