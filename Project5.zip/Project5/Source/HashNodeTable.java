package project5;

public class HashNodeTable {
	public int key;
	public HashTable value;
	
	
	public HashNodeTable(HashTable inValue) {
		key = Math.abs(inValue.hashCode());
		value = inValue;
	}
	
	//public void setKey(String inValue) {
	//	key = Math.abs(inValue.hashCode());
	//}
	
	//public void setValue(String inValue) {
	//	value = inValue;
	//}
	public void clear() {
		value = null;
	}
	public int getKey() {
		return key;
	}
	
	public HashTable getValue() {
		return value;
	}
}
