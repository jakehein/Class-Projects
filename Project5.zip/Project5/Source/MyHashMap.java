/**
 * @description This class creates a HashMap capable of storing String keys and MyVertex values.
 * 				Collision is handled using quadratic probing. 
 * @author Jacob Hein
 * 
 * @verson 5/12/2019
 */
package project5;

public class MyHashMap {
	private String[] key;
	private MyVertex[] value;
	private float loadFactor;
	private int numElements;
	
	public MyHashMap() {
		key = new String[11];
		value = new MyVertex[11];
		numElements = 0;
		loadFactor = (float) numElements / key.length;
	}
	/**
	 * This method returns the number of elements stored in the hashMap
	 * @return numElements
	 */
	public int size() {
		return numElements;
	}
	/**
	 * This method clears the hashMap by instantiating a new hashMap
	 */
	public void clear() {
		key = new String[11];
		value = new MyVertex[11];
		numElements = 0;
		loadFactor = (float) numElements / key.length;
	}
	/**
	 * This method rehashes the hashMap once the table hits its loadFactor
	 * @param primeLength is the length of the new hashMap determined by getting the next largest
	 * 		prime number after the previous prime length of the last map's length.
	 */
	public void rehash(int primeLength) {
		String[] bigStrTable = new String[primeLength];
		MyVertex[] bigVertTable = new MyVertex[primeLength];
		int iElements = numElements;
		int count = 0;
		while (iElements > 0) {
			if (key[count] != null) {
				String word = key[count];
				MyVertex vert = value[count];
				int slot = Math.abs(word.hashCode()) % bigStrTable.length;
				int i = 0;
				int j = slot + (int) Math.pow(i, 2);
				while (bigStrTable[j] != null) {
					i++;
					j = (slot + (int) Math.pow(i, 2)) % bigStrTable.length;
				}
				bigStrTable[j] = word;
				bigVertTable[j] = vert;
				iElements--;
			}
			count++;
		}
		key = bigStrTable;
		value = bigVertTable;
		updateLoadFactor();
	}
	/**
	 * This method updates the loadFactor of the map. If the loadFactor hits .5, rehashing is performed.
	 */
	public void updateLoadFactor() {
		loadFactor = (float) numElements / key.length;
		if (loadFactor >= .5)
			nextPrime(key.length);
	}
	/**
	 * This method finds the next largest prime number after the current prime number being used for the
	 * current table's length.
	 * @param inNumber is the current table's length
	 */
	public void nextPrime(int inNumber) {
		int prime = (inNumber << 1) + 1;
		for (int i = 3; i < prime; i++)
			if (prime % i == 0) {
				prime = prime + 2;
				i = 3;
			}
		rehash(prime);
	}
	/**
	 * This method inserts a key and its associated value into the hashMap then updates the loadFactor.
	 * @param inKey is the key being added.
	 * @param inValue is the value being added.
	 */
	public void insert(String inKey, MyVertex inValue) {
		String word = inKey;
		int slot = Math.abs(word.hashCode()) % key.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		while (key[j] != null) {
			if (value[j].equals(inValue.getVertString()))
				return;
			i++;
			j = (slot + (int) Math.pow(i, 2)) % key.length;
		}
		key[j] = inKey;
		value[j] = inValue;
		numElements++;
		updateLoadFactor();
	}
	/**
	 * This method returns a String of the hashMap.
	 */
	@Override
	public String toString() {
		String string = "Keys: ";
		for (String current : key)
			if (current != null)
				string = string + current + "\n";
		string = string + "\nValues: ";
		for (MyVertex current : value)
			if (current != null)
				string = string + current + "\n";
		return string;
	}
	/**
	 * This method prints the hashMap.
	 */
	public void printHashMap() {
		for (String current : key)
			if (current != null)
				System.out.print("(" + current + ") ");
	}
	/**
	 * This method returns a String[] of the keys in the hashMap.
	 * @return returnArray is the array of keys being returned.
	 */
	public String[] returnKeys() {
		String[] returnArray = new String[numElements];
		int i = 0;
		int count = 0;
		while (i < numElements) {
			if (key[count] != null) {
				returnArray[i] = key[count];
				i++;
			}
			count++;
		}
		return returnArray;
	}
	/**
	 * This method returns a MyVertex[] of the values in the hashMap.
	 * @return returnArray is the array of values being returned.
	 */
	public MyVertex[] returnValues() {
		MyVertex[] returnArray = new MyVertex[numElements];
		int i = 0;
		int count = 0;
		while (i < numElements) {
			if (value[count] != null) {
				returnArray[i] = value[count];
				i++;
			}
			count++;
		}
		return returnArray;
	}
	/**
	 * This method removes a key and value from the hashMap.
	 * @param inKey is the key of the object being removed.
	 */
	public void remove(String inKey) {
		int hashKey = Math.abs(inKey.hashCode());
		int slot = hashKey % key.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		while (key[j] != null) {
			if (key[j].equals(inKey)) {
				key[j] = null;
				value[j] = null;
			}
			i++;
			j = (slot + (int) Math.pow(i, 2)) % key.length;
		}
		numElements--;
	}
	/**
	 * This method searches for a MyVertex object by its associated key and returns the object.
	 * @param inKey is the key of the MyVertex object.
	 * @return value[j] is the MyVertex object being returned.
	 */
	public MyVertex search(String inKey) {
		int hashKey = Math.abs(inKey.hashCode());
		int slot = hashKey % key.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		while (key[j] != null) {
			if (key[j].equals(inKey))
				return value[j];
			i++;
			j = (slot + (int) Math.pow(i, 2)) % key.length;
		}
		return null;
	}
}
