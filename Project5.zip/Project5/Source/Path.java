/**
 * @description This class creates a Path MyLinkedList for finding the shortest path through the graph,
 * 				storing the collective time along the way.
 * @author Jacob Hein
 * 
 * @version 2/12/2019
 */
package project5;

public class Path{
    private int time;
    private MyLinkedList path;
    
    public Path(){
        time = 0;
        path = new MyLinkedList();
    }
    /**
     * Seft Explanatory
     * @return
     */
    public int getTime() {
    	return time;
    }
    /**
     * Self Explanatory
     * @param inTime
     */
    public void setTime(int inTime) {
    	time = inTime;
    }
    /**
     * Self Explanatory
     * @return
     */
    public MyLinkedList getPath() {
    	return path;
    }
}