package project5;

public class HashTable {
	private HashNode[] hashTable;
	private float loadFactor;
	private int numElements;
	
	public HashTable() {
		hashTable = new HashNode[11];
		numElements = 0;
		loadFactor = (float) numElements / hashTable.length;
	}
	
	public int size() {
		return numElements;
	}
	
	public void clear() {
		hashTable = new HashNode[11];
		numElements = 0;
		loadFactor = (float) numElements / hashTable.length;
	}
	public void rehash(int primeLength) {
		HashNode[] bigTable = new HashNode[primeLength];
		int iElements = numElements;
		int count = 0;
		while (iElements > 0) {
			if (hashTable[count] != null) {
				////
				
				HashNode word = hashTable[count];
				int slot = word.getKey() % bigTable.length;
				int i = 0;
				int j = slot + (int) Math.pow(i,2);
				
				while (bigTable[j] != null) {
					i++;
					j = (slot + (int) Math.pow(i,2)) % bigTable.length;
				}
				bigTable[j] = word;
				////
				iElements--;
			}
			count++;
		}
		hashTable = bigTable;
		updateLoadFactor();
	}
	
	public void updateLoadFactor() {
		loadFactor = (float) numElements / hashTable.length;
		if(loadFactor >= .5)
			nextPrime(hashTable.length);
	}
	
	public void nextPrime(int inNumber) {
			int prime = (inNumber << 1) + 1;
			for (int i = 3; i < prime; i++)
				if (prime % i == 0) {
					prime = prime + 2;
					i = 3;
				}
		rehash(prime);
	}
	
	public void insert(MyVertex inValue) {//String inValue) {
		HashNode word = new HashNode(inValue);
		int slot = word.getKey() % hashTable.length;
		int i = 0;
		int j = slot + (int) Math.pow(i,2);
		
		while (hashTable[j] != null) {
			if(hashTable[j].getValue().getVertString().contentEquals(inValue.getVertString())) { //attempting to prevent duplicates
				//was hashTable[j].value().contentEquals(inValue)
				return;
			}
			i++;
			j = (slot + (int) Math.pow(i, 2)) % hashTable.length;
		}
		//if(hashTable[j].value.contentEquals(inValue))
		hashTable[j] = word;
		numElements++;
		updateLoadFactor();
	}
	
	@Override
	public String toString() {
		String string = "";
		for(HashNode current : hashTable) {
			if (current != null)
				string = string + current.getValue() + "\n";
		}
		return string;
	}
	
	public void printHash() {
		
		System.out.print("Table: [");
		for(HashNode current : hashTable) {
			if (current != null)
				System.out.print("(" + /*current.getKey() + "," +*/ current.getValue() + "), ");
		}
		System.out.print("]");
		
	}
	
	public HashNode[] returnTable() {
		return hashTable;
	}
	
	public void remove(int inKey) {
		int slot = inKey % hashTable.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		//int iSquared = (int) Math.pow(i, 2);
		
		while (hashTable[j] != null) {
			if (hashTable[j].getKey() == inKey)
				//return hashTable[j];
				hashTable[j].clear();
			i++;
			j = (slot + (int) Math.pow(i, 2)) % hashTable.length;
		}
		numElements--;
		//HashNode element = new HashNode();
		//return null; //element;
	}
	
	public HashNode search(int inKey) {
		int slot = inKey % hashTable.length;
		int i = 0;
		int j = slot + (int) Math.pow(i, 2);
		//int iSquared = (int) Math.pow(i, 2);
		
		while (hashTable[j] != null) {
			if (hashTable[j].getKey() == inKey)
				return hashTable[j];
			i++;
			j = (slot + (int) Math.pow(i, 2)) % hashTable.length;
		}
		//HashNode element = new HashNode();
		return null; //element;
	}
}
